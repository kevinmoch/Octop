"""Persistent recording store."""

from __future__ import annotations

import json
import re
import shutil
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from octop_browser.record.models import RecordingManifest, StepsDocument
from octop_browser.record.settings import RecordReplaySettings
from octop_browser.record.settings import settings as default_settings


class RecordingStore:
    def __init__(self, cfg: RecordReplaySettings | None = None) -> None:
        self.cfg = cfg or default_settings
        if self.cfg.retention_days < 1 or self.cfg.max_recordings_per_profile < 1:
            raise ValueError("Recording retention and capacity limits must be positive")
        self.base_dir = self.cfg.base_dir
        self.recordings_dir = self.base_dir / "recordings"

    def ensure_base(self) -> None:
        self.recordings_dir.mkdir(parents=True, exist_ok=True)
        try:
            self.base_dir.chmod(0o700)
            self.recordings_dir.chmod(0o700)
        except OSError:
            pass

    def recording_dir(self, recording_id: str) -> Path:
        return self.recordings_dir / recording_id

    def manifest_path(self, recording_id: str) -> Path:
        return self.recording_dir(recording_id) / "manifest.json"

    def events_path(self, recording_id: str) -> Path:
        return self.recording_dir(recording_id) / "events.jsonl"

    def steps_path(self, recording_id: str) -> Path:
        return self.recording_dir(recording_id) / "steps.json"

    def skill_path(self, recording_id: str, draft: bool = True) -> Path:
        return self.recording_dir(recording_id) / (
            "draft.skill.md" if draft else "final.skill.md"
        )

    def create(self, manifest: RecordingManifest) -> Path:
        self.ensure_base()
        rec_dir = self.recording_dir(manifest.recording_id)
        rec_dir.mkdir(parents=True, exist_ok=False)
        for sub in ("screenshots", "snapshots", "replay-reports"):
            (rec_dir / sub).mkdir(exist_ok=True)
        try:
            rec_dir.chmod(0o700)
        except OSError:
            pass
        self.write_manifest(manifest)
        events = self.events_path(manifest.recording_id)
        events.touch(exist_ok=False)
        try:
            events.chmod(0o600)
        except OSError:
            pass
        self.enforce_retention(manifest.profile)
        return rec_dir

    def delete(
        self,
        recording_id: str,
        *,
        profile: str,
        reason: str = "user",
        now: datetime | None = None,
    ) -> None:
        if re.fullmatch(r"[A-Za-z0-9_-]{1,128}", recording_id) is None:
            raise FileNotFoundError(recording_id)
        manifest = self.read_manifest(recording_id)
        if manifest.profile != profile:
            raise FileNotFoundError(recording_id)
        if manifest.status == "recording":
            raise ValueError("Stop the recording before deleting it")
        rec_dir = self.recording_dir(recording_id)
        if rec_dir.parent != self.recordings_dir or rec_dir.is_symlink():
            raise ValueError("The recording directory is not safe to delete")
        shutil.rmtree(rec_dir)
        deleted_at = now or datetime.now(timezone.utc)
        if deleted_at.tzinfo is None:
            raise ValueError("The deletion timestamp must include a timezone")
        self.ensure_base()
        with (self.base_dir / "deletion-tombstones.jsonl").open(
            "a", encoding="utf-8"
        ) as tombstones:
            tombstones.write(
                json.dumps(
                    {
                        "recordingId": recording_id,
                        "profile": profile,
                        "reason": reason,
                        "deletedAt": deleted_at.isoformat(),
                    },
                    separators=(",", ":"),
                )
                + "\n"
            )

    def enforce_retention(
        self, profile: str, *, now: datetime | None = None
    ) -> list[str]:
        reference = now or datetime.now(timezone.utc)
        if reference.tzinfo is None:
            raise ValueError("The retention timestamp must include a timezone")
        dated: list[tuple[datetime, RecordingManifest]] = []
        recordings = self.list_recordings()
        active_count = sum(
            manifest.profile == profile and manifest.status == "recording"
            for manifest in recordings
        )
        for manifest in recordings:
            if manifest.profile != profile or manifest.status == "recording":
                continue
            try:
                created = datetime.fromisoformat(
                    manifest.created_at.replace("Z", "+00:00")
                )
            except ValueError:
                continue
            if created.tzinfo is None:
                continue
            dated.append((created, manifest))
        expired = [
            manifest
            for created, manifest in dated
            if created <= reference - timedelta(days=self.cfg.retention_days)
        ]
        remaining = sorted(
            (item for item in dated if item[1] not in expired),
            key=lambda item: (item[0], item[1].recording_id),
            reverse=True,
        )
        deleted: list[str] = []
        available = max(0, self.cfg.max_recordings_per_profile - active_count)
        for manifest in [
            *expired,
            *(item[1] for item in remaining[available:]),
        ]:
            self.delete(
                manifest.recording_id,
                profile=profile,
                reason="retention",
                now=reference,
            )
            deleted.append(manifest.recording_id)
        return deleted

    def write_manifest(self, manifest: RecordingManifest) -> None:
        path = self.manifest_path(manifest.recording_id)
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(
            json.dumps(
                manifest.model_dump(mode="json", by_alias=True),
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        tmp.replace(path)

    def read_manifest(self, recording_id: str) -> RecordingManifest:
        data = json.loads(self.manifest_path(recording_id).read_text(encoding="utf-8"))
        return RecordingManifest.model_validate(data)

    def append_event(self, recording_id: str, event: dict[str, Any]) -> None:
        line = json.dumps(event, ensure_ascii=False, separators=(",", ":"))
        with self.events_path(recording_id).open("a", encoding="utf-8") as f:
            f.write(line + "\n")
            f.flush()

    def read_events(self, recording_id: str) -> list[dict[str, Any]]:
        path = self.events_path(recording_id)
        events: list[dict[str, Any]] = []
        if not path.exists():
            return events
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            events.append(json.loads(line))
        return events

    def write_steps(self, recording_id: str, steps: StepsDocument) -> Path:
        path = self.steps_path(recording_id)
        path.write_text(
            json.dumps(
                steps.model_dump(mode="json", by_alias=True),
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        return path

    def read_steps(self, recording_id: str) -> StepsDocument:
        return StepsDocument.model_validate_json(
            self.steps_path(recording_id).read_text(encoding="utf-8")
        )

    def write_skill(self, recording_id: str, content: str, draft: bool = True) -> Path:
        path = self.skill_path(recording_id, draft=draft)
        path.write_text(content, encoding="utf-8")
        return path

    def list_recordings(self) -> list[RecordingManifest]:
        self.ensure_base()
        manifests: list[RecordingManifest] = []
        for path in sorted(self.recordings_dir.glob("*/manifest.json")):
            try:
                manifests.append(
                    RecordingManifest.model_validate_json(
                        path.read_text(encoding="utf-8")
                    )
                )
            except Exception:  # pylint: disable=broad-except
                continue
        return manifests

    def recording_summary(self, recording_id: str) -> dict[str, Any]:
        manifest = self.read_manifest(recording_id)
        rec_dir = self.recording_dir(recording_id)
        steps = self.steps_path(recording_id)
        draft = self.skill_path(recording_id, draft=True)
        final = self.skill_path(recording_id, draft=False)
        reports = sorted((rec_dir / "replay-reports").glob("replay_*.json"))
        latest_report = reports[-1] if reports else None
        return {
            "recordingId": recording_id,
            "status": manifest.status,
            "profile": manifest.profile,
            "createdAt": manifest.created_at,
            "endedAt": manifest.ended_at,
            "startUrl": manifest.target.start_url,
            "endUrl": manifest.target.end_url,
            "events": manifest.stats.events,
            "steps": manifest.stats.steps,
            "recordingDir": str(rec_dir),
            "manifestPath": str(self.manifest_path(recording_id)),
            "eventsPath": str(self.events_path(recording_id)),
            "stepsPath": str(steps) if steps.exists() else "",
            "skillDraft": str(draft) if draft.exists() else "",
            "skillFinal": str(final) if final.exists() else "",
            "latestReplayReport": str(latest_report) if latest_report else "",
            "hasSteps": steps.exists(),
            "hasSkillDraft": draft.exists(),
        }
